# Creates a basic manager that is used to manage the users collection in MongoDB

"""
Format:

If database is empty create collection

Collection: users
Fields: discord_id: String, torn_username: String, days_left: Integer, last_updated: String, admin: Boolean

If not it stops the script for now

"""

import os
import argparse
from datetime import datetime
from pymongo import MongoClient
import environ
import subprocess

# Load environment variables
env = environ.Env()
environ.Env.read_env()

# Debugging: Print environment variables
print("Environment variables:")
print(f"OWNER_KEY: {env('OWNER_KEY', default='Not Set')}")
print(f"BOT_KEY: {env('BOT_KEY', default='Not Set')}")

mongo_url = env('MONGO_REMOTE')

# Connect to MongoDB
client = MongoClient(mongo_url)
db = client.subscribers
users_collection = db.users

db_leveling = client.sub_leveling
leveling_collection = db_leveling.levels

def setup_database():
    # Check if the collection is empty
    if users_collection.count_documents({}) == 0:
        # Add basic dummy data
        users_collection.insert_many([
            {"discord_id": "1199594716770082886", "torn_username": "Hyperfox25", "days_left": 10000, "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S'), "admin": True},
            {"discord_id": "918441835133825035", "torn_username": "JancoNel", "days_left": 10000, "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S'), "admin": True},
            {"discord_id": "1296114314335228070", "torn_username": "DarthJeff", "days_left": 10000, "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S'), "admin": True}
        ])

def setup_leveling():
    # Check if the collection is empty
    if leveling_collection.count_documents({}) == 0:
        # Add basic dummy data
        leveling_collection.insert_many([
            {"discord_id": "1199594716770082886", "xp": 0, "level": 1},
            {"discord_id": "918441835133825035", "xp": 0, "level": 1},
            {"discord_id": "1296114314335228070", "xp": 0, "level": 1}
        ])

def add_days(discord_id, days):
    users_collection.update_one({"discord_id": discord_id}, {"$inc": {"days_left": days}})

def start_main_script():
    try:
        subprocess.run(["python", "main.py"], check=True)
    except subprocess.CalledProcessError:
        subprocess.run(["python3", "main.py"], check=True)

def display_help():
    help_message = """
    Available commands:
    setup - Initialize the database and add dummy data.
    plus <DiscordID> <days> - Add a specified number of days to a user.
    help - Display this help message.
    setup_leveling - Initialize the leveling database and add dummy data.
    start - Run the main.py script.
    """
    print(help_message)

def main():
    parser = argparse.ArgumentParser(description='Manage the users database.')
    parser.add_argument('command', choices=['setup', 'plus', 'help', 'setup_leveling', 'start'], help='Command to run')
    parser.add_argument('discord_id', nargs='?', help='Discord ID of the user')
    parser.add_argument('days', type=int, nargs='?', help='Number of days to add')
    args = parser.parse_args()

    if args.command == 'setup':
        setup_database()
    elif args.command == 'plus':
        if args.discord_id and args.days:
            add_days(args.discord_id, args.days)
        else:
            print('Please provide both Discord ID and number of days.')
    elif args.command == 'help':
        display_help()
    elif args.command == 'setup_leveling':
        setup_leveling()
    elif args.command == 'start':
        start_main_script()

if __name__ == '__main__':
    main()