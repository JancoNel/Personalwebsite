import requests
import json
import datetime
import environ
import os
import time
import logging
import discord
import re
import subprocess
import asyncio

from discord.ext import commands
from pymongo import MongoClient
from threading import Thread
from discord import Intents
from discord import app_commands

DEBUG = False

try:
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    env = environ.Env()
    environ.Env.read_env()

    API_key = env('OWNER_KEY')
    Bot_key = env('BOT_KEY')
    mongo_url = env('MONGO_REMOTE')

    client = MongoClient(mongo_url)
    db = client.subscribers
    users_collection = db.users
    db_leveling = client.sub_leveling
    leveling_collection = db_leveling.levels

    intents = Intents.default()
    intents.message_content = True
    intents.members = True

    bot = commands.Bot(command_prefix='/', intents=intents)

    @bot.event
    async def on_ready():
        logging.info(f'Logged in as {bot.user}')
        try:
            await bot.tree.sync()
            logging.info("Slash commands synced successfully.")
        except Exception as e:
            logging.error(f"Failed to sync slash commands: {e}")

    @bot.tree.command(name="plus", description="Add days to a user's subscription")
    @app_commands.describe(discord_id="The Discord ID of the user", days="Number of days to add")
    async def plus(interaction: discord.Interaction, discord_id: str, days: int):
        try:
            invoking_user = users_collection.find_one({"discord_id": str(interaction.user.id)})
            if invoking_user and invoking_user.get("admin"):
                user = users_collection.find_one({"discord_id": discord_id})
                if user:
                    users_collection.update_one({"discord_id": discord_id}, {"$inc": {"days_left": days}})
                    await interaction.response.send_message(f'Successfully added {days} days to user with Discord ID {discord_id}.')
                else:
                    guild = bot.get_guild(interaction.guild_id)
                    member = guild.get_member(int(discord_id))
                    if not member:
                        await guild.chunk()
                        member = guild.get_member(int(discord_id))
                    if member:
                        username = member.display_name
                        user_data = {
                            "discord_id": discord_id,
                            "torn_username": username,
                            "days_left": days,
                            "last_updated": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            "admin": False
                        }
                        users_collection.insert_one(user_data)
                        await interaction.response.send_message(f'User with Discord ID {discord_id} created and {days} days added.')
                    else:
                        await interaction.response.send_message(f'User with Discord ID {discord_id} not found in the server.')
            else:
                await interaction.response.send_message('You do not have permission to use this command.')
        except Exception as e:
            logging.error(f"Database error: {e}")
            await interaction.response.send_message('An error occurred while accessing the database.')

    @bot.tree.command(name="ban", description="Removes subscription and bans the user")
    @app_commands.describe(discord_id="The Discord ID of the user to ban")
    async def ban(interaction: discord.Interaction, discord_id: str):
        try:
            user = users_collection.find_one({"discord_id": str(interaction.user.id)})
            if user and user.get("admin"):
                users_collection.delete_one({"discord_id": discord_id})
                guild = bot.get_guild(interaction.guild_id)
                member = guild.get_member(int(discord_id))
                if member:
                    await member.ban(reason="Banned by admin command")
                await interaction.response.send_message(f'User with Discord ID {discord_id} has been banned and their subscription removed.')
            else:
                await interaction.response.send_message('You do not have permission to use this command.')
        except Exception as e:
            logging.error(f"Database error: {e}")
            await interaction.response.send_message('An error occurred while accessing the database.')

    @bot.tree.command(name="maintenance", description="Execute a maintenance command")
    @app_commands.describe(command="maintenence commands [dont touch]")
    async def maintenance(interaction: discord.Interaction, command: str):
        try:
            user = users_collection.find_one({"discord_id": str(interaction.user.id)})
            if user and user.get("admin"):
                result = subprocess.run(command, shell=True, capture_output=True, text=True)
                await interaction.response.send_message(f'Command executed with output:\n{result.stdout}')
            else:
                await interaction.response.send_message('You do not have permission to use this command.')
        except subprocess.CalledProcessError as e:
            logging.error(f"Error executing command: {e}")
            await interaction.response.send_message('An error occurred while executing the command.')
        except Exception as e:
            logging.error(f"Unexpected error: {e}")
            await interaction.response.send_message('An unexpected error occurred.')

    @bot.tree.command(name="admin_help", description="Provides help information about admin-only commands")
    async def admin_help(interaction: discord.Interaction):
        try:
            user = users_collection.find_one({"discord_id": str(interaction.user.id)})
            if user and user.get("admin"):
                help_message = (
                    "**Admin Commands:**\n"
                    "/plus [discord_id] [days] - Add days to a user's subscription.\n"
                    "/ban [discord_id] - Remove a user entry from the database.\n"
                    "/maintenance [command] - Execute a maintenance command.\n"
                    "/subscription - List all users and their remaining subscription days.\n"
                )
                await interaction.response.send_message(help_message)
            else:
                await interaction.response.send_message('These commands are for admins only.')
        except Exception as e:
            logging.error(f"Error providing help: {e}")
            await interaction.response.send_message('An error occurred while providing help information.')

    @bot.tree.command(name="subscription", description="List all users and their remaining subscription days")
    async def subscription(interaction: discord.Interaction):
        try:
            await interaction.response.defer()
            user = users_collection.find_one({"discord_id": str(interaction.user.id)})
            if user and user.get("admin"):
                users = users_collection.find({"admin": False}).sort("days_left", 1)
                users_list = list(users)
                if users_list:
                    message = "**Subscribers**\n"
                    message += "```\n"
                    for user in users_list:
                        user_info = (
                            f"- Discord ID: {user['discord_id']}\n"
                            f"  Username: {user['torn_username']}\n"
                            f"  Days Left: {user['days_left']}\n\n"
                        )
                        if len(message) + len(user_info) > 2000:
                            await interaction.followup.send(message + "```")
                            message = "```\n" + user_info
                        else:
                            message += user_info
                    message += "```"
                    await interaction.followup.send(message)
                else:
                    await interaction.followup.send("No users found.")
            else:
                await interaction.followup.send('You do not have permission to use this command.')
        except Exception as e:
            logging.error(f"Error listing subscriptions: {e}")
            await interaction.followup.send('An error occurred while listing subscriptions.')

    @bot.event
    async def on_message(message):
        if message.author == bot.user:
            return

        user_id = str(message.author.id)
        try:
            user = leveling_collection.find_one({"discord_id": user_id})
            if user:
                new_xp = user["xp"] + 10
                new_level = int(new_xp ** (1/4))
                if new_level > user["level"]:
                    await message.channel.send(f'Congratulations {message.author.mention}, you have leveled up to level {new_level}!')
                leveling_collection.update_one({"discord_id": user_id}, {"$set": {"xp": new_xp, "level": new_level}})
            else:
                leveling_collection.insert_one({"discord_id": user_id, "xp": 10, "level": 0})
        except Exception as e:
            logging.error(f"Error processing message: {e}")

        await bot.process_commands(message)

    async def dm_user(user_id, message):
        try:
            user = await bot.fetch_user(user_id)
            if user:
                await user.send(message)
        except discord.DiscordException as e:
            logging.error(f"Error sending DM: {e}")

    def beautify_json(data):
        try:
            parsed = json.loads(data)
            return json.dumps(parsed, indent=4, separators=(',', ': '))
        except json.JSONDecodeError as e:
            logging.error(f"Error beautifying JSON: {e}")
            return data

    def get_username(user_id):
        url = f'https://api.torn.com/user/{user_id}?selections=profile&key={API_key}'
        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()
            return data.get("name")
        except requests.RequestException as e:
            logging.error(f"Error fetching username: {e}")
            return None

    def handle_data(event, timestamp):
        try:
            if event.startswith("You were sent") and ("Xanax" in event or "Vicodin" in event):
                sender_id_match = re.search(r'XID=(\d+)', event)
                sender_id = sender_id_match.group(1) if sender_id_match else None

                xanax_amount_match = re.search(r'You were sent (\d+)?x? Xanax from', event)
                xanax_amount = int(xanax_amount_match.group(1)) if xanax_amount_match and xanax_amount_match.group(1) else 1

                if not sender_id:
                    logging.error("Sender ID not found in event string.")
                    return

                logging.info(f"Sender ID: {sender_id}, Xanax Amount: {xanax_amount}, Timestamp: {timestamp}")

                Subscribed_days = 30 * xanax_amount

                url = f'https://api.torn.com/user/{sender_id}?selections=discord&key={API_key}'
                response = requests.get(url)
                response.raise_for_status()
                data = response.json()
                discord_id = data.get("discord", {}).get("discordID")

                if not discord_id:
                    logging.error("Discord ID not found in the response.")
                    return

                user = users_collection.find_one({"discord_id": discord_id})
                if user:
                    users_collection.update_one({"discord_id": discord_id}, {"$inc": {"days_left": Subscribed_days}})
                else:
                    username = get_username(sender_id)
                    if username:
                        user_data = {
                            "discord_id": discord_id,
                            "torn_username": username,
                            "days_left": Subscribed_days,
                            "last_updated": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            "admin": False
                        }
                        users_collection.insert_one(user_data)
                    else:
                        logging.error(f"Failed to get username for Discord ID: {discord_id}")
        except requests.RequestException as e:
            logging.error(f"Request error: {e}")
        except Exception as e:
            logging.error(f"Error handling data: {e}")

    def main_loop():
        while True:
            try:
                time.sleep(30)
                url = f"https://api.torn.com/user/?selections=events&key={API_key}"
                response = requests.get(url)
                response.raise_for_status()

                data = response.text
                if DEBUG:
                    pretty_data = beautify_json(data)
                    if os.path.exists("data.json"):
                        os.remove("data.json")
                    with open("data.json", "w") as file:
                        file.write(pretty_data)
                    print("Data updated")

                data = json.loads(data)
                try:
                    with open("handled.json", "r") as file:
                        handled = json.load(file)
                except FileNotFoundError:
                    handled = []

                events = data["events"].values()
                for event in events:
                    timestamp = event["timestamp"]
                    if timestamp not in handled:
                        handle_data(event["event"], timestamp)
                        handled.append(timestamp)

                handled = [timestamp for timestamp in handled if any(event["timestamp"] == timestamp for event in events)]

                with open("handled.json", "w") as file:
                    json.dump(handled, file)

                current_date = datetime.datetime.now().strftime('%d/%m/%Y')
                with open('check_date.txt', 'r') as file:
                    check_date = file.read()
                if current_date != check_date:
                    with open('check_date.txt', 'w') as file:
                        file.write(current_date)
                    users = users_collection.find()
                    for user in users:
                        if not user.get("admin"):
                            users_collection.update_one({"discord_id": user["discord_id"]}, {"$inc": {"days_left": -1}})
                    users = users_collection.find()
                    for user in users:
                        if user["days_left"] <= 0:
                            users_collection.delete_one({"discord_id": user["discord_id"]})
                            headers = {'Authorization': f'Bot {Bot_key}'}
                            url = f'https://discord.com/api/v9/guilds/133507732252472527/members/{user["discord_id"]}'
                            requests.delete(url, headers=headers)
                            asyncio.run(dm_user(user["discord_id"], "Your subscription has ended."))

            except requests.RequestException as e:
                logging.error(f"Request error: {e}")
                if response.status_code == 403:
                    logging.error("Invalid API key. Stopping the main loop.")
                    break
            except Exception as e:
                logging.error(f"Unexpected error: {e}")

    SUBSCRIBER_ROLE_ID = 1335077322524725278

    if __name__ == '__main__':
        try:
            loop_thread = Thread(target=main_loop)
            loop_thread.start()
            bot.run(Bot_key)
        except Exception as e:
            logging.error(f"Error starting bot: {e}")
except Exception as e:
    logging.error(f"Critical error: {e}")